from manim import *

class Shapes2(Scene):
    def construct(self):
        # Creación de un rectángulo
        rect = Rectangle()
        rect.set_fill(PINK, opacity=0.5)
        # Mostrar el rectángulo en la escena
        self.play(Create(rect))
        self.play(FadeOut(rect))

        # Crear un nuevo rectángulo con color azul, altura de 3 y ancho de 1
        rect = Rectangle(color=PURPLE, height=3, width=1)
        rect.set_fill(PURPLE_A, opacity=0.5)
        self.play(Create(rect))
        self.play(FadeOut(rect))