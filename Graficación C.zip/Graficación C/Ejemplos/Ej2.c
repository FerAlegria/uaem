# include < stdio .h>
# include < stdlib .h>
# include < unistd .h>
# include < sys / types .h>
# include < sys / wait .h>

int main () {
pid_t pid;
int i=0 , estado ;
pid = fork () ;
if( pid == -1) {
  perror (" Error en la creación del proceso \n") ;
  return -1;
 } else if( pid == 0) {
  printf(" Soy el proceso hijo - PID :␣ %d,␣ PPID :␣ %d,␣i:␣ %d\
n", getpid () , getppid () , i ++) ;
   return 0;
} else {
  printf(" Soy ␣el␣ proceso ␣ padre ␣-␣PID:␣ %d,␣ PPID :␣ %d,␣i:␣ %d
\n", getpid () , getppid () , i - -) ;
   wait (& estado ) ;
  
   return 0;
   }
}
