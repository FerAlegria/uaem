from manim import *
class SquareAndCircle(Scene):
    def construct(self):
        circleR = Circle()  # create a circle
        circleR.set_fill(PURPLE, opacity=0.5)  # set the color and transparency
        circleR.to_corner(UR) 

        squareL= Square()  # create a square
        squareL.set_fill(BLUE, opacity=0.5)  # set the color and transparency
        squareL.to_corner(DL) 

        circleL= Circle()  # create a square
        circleL.set_fill(GREEN, opacity=0.5)  # set the color and transparency
        circleL.to_corner(DR) 

        squareR= Square()  # create a square
        squareR.set_fill(GREY, opacity=0.5)  # set the color and transparency
        squareR.to_corner(UL) 
        
         # Mostrar todas las formas en la pantalla
        self.play(Create(circleR), Create(squareL),
                  Create(circleL), Create(squareR))
        