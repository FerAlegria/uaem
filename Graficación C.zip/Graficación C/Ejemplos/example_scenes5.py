from manim import *
import numpy as np

class Shapes(Scene):
    def construct(self):
        # Creación de un círculo
        circulo = Circle(color=RED)
        circulo.set_fill(BLUE, opacity=0.5)
        # Animación para mostrar la creación del círculo
        self.play(Create(circulo))  # Usa 'Create' en lugar de 'ShowCreation'

        # Mantén la animación en pantalla
        self.wait(2)
        fadeOutCircle = FadeOut(circulo) # Animación de desaparición
        self.play(fadeOutCircle) # Mostrar la animación
