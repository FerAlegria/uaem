


x1=0
x2=80

y1=0
y2=80
#Editamos los ejes
plt.axis([x1,x2,y1,y2])
plt.axis('on')
plt.grid(True)
plt.title("Ejemplo 1")

dx=5
dy=5
#Graficar puntos
for x in np.arange(x1, x2, dx):
    for y in np.arange(y1, y2, dy):
            #plt.scatter(x_array, yarray. s_tamaño, color, etc)
            plt.scatter(x,y, s=1.5, color ='lightgray')
#Graficando el vector
    #x,y,incremento, abscisa, longitud, ancho, color
plt.arrow(0,80,5,0,head_length=4, head_width=4, color = 'k')#k is black and b is blue