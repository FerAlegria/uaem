import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
import numpy as np

# Configuración de la figura
fig, ax = plt.subplots(figsize=(6, 4))
ax.set_xlim(-3, 3)
ax.set_ylim(-2, 2)
ax.set_aspect('equal')
ax.axis('off')  # Ocultar los ejes

# Lista de frames para animación detallada
frames = []

# Parámetros de movimiento
cloud_x_position = np.linspace(-3, 3, 50)  # Movimiento de la nube de izquierda a derecha
rain_drops = []  # Lista para las gotas de lluvia

# Paso 1: Crear la base de la nube usando círculos y rellenarlos con color
base_circle1 = patches.Circle((-1.2, 0), radius=1, edgecolor="lightblue", facecolor="lightblue", lw=3)
base_circle2 = patches.Circle((0, 0), radius=1.2, edgecolor="lightblue", facecolor="lightblue", lw=3)
base_circle3 = patches.Circle((1.2, 0), radius=1, edgecolor="lightblue", facecolor="lightblue", lw=3)
top_circle = patches.Circle((0, 1), radius=0.8, edgecolor="lightblue", facecolor="lightblue", lw=3)
face_cover = patches.Circle((0, 0), radius=1.1, edgecolor="none", facecolor="lightblue")

# Crear ojos y expresión triste
eye_left = patches.Circle((-0.5, 0.4), radius=0.15, edgecolor="gray", facecolor="gray")
eye_right = patches.Circle((0.5, 0.4), radius=0.15, edgecolor="gray", facecolor="gray")
eye_left_shine = patches.Circle((-0.53, 0.45), radius=0.05, edgecolor="white", facecolor="white")
eye_right_shine = patches.Circle((0.47, 0.45), radius=0.05, edgecolor="white", facecolor="white")
sad_mouth = patches.Arc((0, -0.1), width=0.6, height=0.4, theta1=20, theta2=160, edgecolor="gray", lw=1.5)

# Generar gotas de lluvia en posiciones iniciales aleatorias
for _ in range(10):  # Crear 10 gotas de lluvia
    drop_x = np.random.uniform(-1.5, 1.5)
    drop_y = np.random.uniform(-0.5, -1.5)
    drop = patches.Circle((drop_x, drop_y), radius=0.05, edgecolor="blue", facecolor="blue")
    rain_drops.append(drop)

# Crear frames para animación
for i, x_pos in enumerate(cloud_x_position):
    # Mover la nube en cada paso de animación
    updated_base_circle1 = patches.Circle((-1.2 + x_pos, 0), radius=1, edgecolor="lightblue", facecolor="lightblue", lw=3)
    updated_base_circle2 = patches.Circle((0 + x_pos, 0), radius=1.2, edgecolor="lightblue", facecolor="lightblue", lw=3)
    updated_base_circle3 = patches.Circle((1.2 + x_pos, 0), radius=1, edgecolor="lightblue", facecolor="lightblue", lw=3)
    updated_top_circle = patches.Circle((0 + x_pos, 1), radius=0.8, edgecolor="lightblue", facecolor="lightblue", lw=3)
    updated_face_cover = patches.Circle((0 + x_pos, 0), radius=1.1, edgecolor="none", facecolor="lightblue")
    
    updated_eye_left = patches.Circle((-0.5 + x_pos, 0.4), radius=0.15, edgecolor="gray", facecolor="gray")
    updated_eye_right = patches.Circle((0.5 + x_pos, 0.4), radius=0.15, edgecolor="gray", facecolor="gray")
    updated_eye_left_shine = patches.Circle((-0.53 + x_pos, 0.45), radius=0.05, edgecolor="white", facecolor="white")
    updated_eye_right_shine = patches.Circle((0.47 + x_pos, 0.45), radius=0.05, edgecolor="white", facecolor="white")
    updated_sad_mouth = patches.Arc((0 + x_pos, -0.1), width=0.6, height=0.4, theta1=20, theta2=160, edgecolor="gray", lw=1.5)

    # Actualizar la posición de las gotas de lluvia
    updated_rain_drops = []
    for drop in rain_drops:
        # Mover cada gota hacia abajo
        new_drop_y = drop.center[1] - 0.05
        if new_drop_y < -2:  # Resetear gota si sale de la pantalla
            new_drop_y = -0.5
        updated_drop = patches.Circle((drop.center[0] + x_pos, new_drop_y), radius=0.05, edgecolor="blue", facecolor="blue")
        updated_rain_drops.append(updated_drop)

    # Añadir todos los elementos de este frame a la lista de frames
    frames.append([updated_base_circle1, updated_base_circle2, updated_base_circle3, updated_top_circle,
                   updated_face_cover, updated_eye_left, updated_eye_right, updated_eye_left_shine, 
                   updated_eye_right_shine, updated_sad_mouth] + updated_rain_drops)

# Función para actualizar la animación
def update(frame):
    ax.clear()
    ax.set_xlim(-3, 3)
    ax.set_ylim(-2, 2)
    ax.axis('off')
    for element in frame:
        ax.add_patch(element)

# Crear la animación
ani = FuncAnimation(fig, update, frames=frames, repeat=True, blit=False)
plt.show()
