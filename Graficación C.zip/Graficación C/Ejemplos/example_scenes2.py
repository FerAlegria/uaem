from manim import *

class WriteStuff(Scene):
    def construct(self):
        example_text = Tex("Me llamo:", tex_to_color_map={"text": YELLOW})
        example_tex = MathTex("\t{David Soto Mora}")
        group = VGroup(example_text, example_tex)
        group.arrange(DOWN)
        group.set_width(config.frame_width - 2 * LARGE_BUFF)  # Cambio aquí

        self.play(Write(example_text))
        self.play(Write(example_tex))
        
        self.wait()