import matplotlib.pyplot as plt
import numpy as np

# Configuración de la figura
fig, ax = plt.subplots(figsize=(10, 6))
ax.set_facecolor("black")  # Fondo negro para el cielo nocturno

# Dibujar la luna llena
moon = plt.Circle((0.8, 0.8), 0.1, color="white", zorder=2)  # Luna en la esquina superior derecha
ax.add_artist(moon)

# Dibujar las estrellas
np.random.seed(42)  # Semilla para reproducibilidad
stars_x = np.random.uniform(0, 1, 80)  # Coordenadas X aleatorias
stars_y = np.random.uniform(0.6, 1, 80)  # Coordenadas Y aleatorias
stars_size = np.random.uniform(5, 15, 80)  # Tamaños variados de estrellas
ax.scatter(stars_x, stars_y, color="white", s=stars_size, alpha=0.8, zorder=1)

# Dibujar los edificios
building_colors = ["dimgray", "darkslategray", "slategray"]
building_positions = [0.05, 0.18, 0.31, 0.44, 0.57, 0.7, 0.83]  # Posiciones X
building_heights = [0.2, 0.4, 0.3, 0.5, 0.35, 0.45, 0.25]  # Alturas de edificios

for i, (x, height) in enumerate(zip(building_positions, building_heights)):
    width = 0.1  # Ancho del edificio
    ax.bar(
        x,
        height,
        width=width,
        color=building_colors[i % len(building_colors)],
        edgecolor="black",
        zorder=3,
    )
    
    # Dibujar ventanas más pequeñas y bien distribuidas
    num_windows_vertical = int(height / 0.06)  # Filas de ventanas, ajustadas a la altura del edificio
    num_windows_horizontal = 2  # Columnas de ventanas
    for row in range(num_windows_vertical):
        for col in range(num_windows_horizontal):
            window_width = 0.02  # Ancho de cada ventana
            window_height = 0.04  # Altura de cada ventana
            window_spacing_x = 0.03  # Espacio entre ventanas horizontalmente
            window_spacing_y = 0.05  # Espacio entre ventanas verticalmente
            
            window_x = x + 0.01 + col * window_spacing_x  # Posición X
            window_y = row * window_spacing_y + 0.02  # Posición Y
            
            if window_y + window_height <= height:  # Solo agregar ventanas dentro del edificio
                ax.add_patch(
                    plt.Rectangle((window_x, window_y), window_width, window_height, color="yellow", zorder=4)
                )

# Configuración de límites y ocultar ejes
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")

# Guardar y mostrar la imagen
plt.savefig("night_cityscape_adjusted.png", dpi=300, bbox_inches="tight")
plt.show()
