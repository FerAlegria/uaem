from manim import *

class DifferentRotations(Scene):
    def construct(self):
        left_circle = Circle(color=BLUE, fill_opacity=0.7).shift(2 * LEFT)
        right_square = Square(color=GREEN, fill_opacity=0.7).shift(2 * RIGHT)
        self.play(
            left_circle.animate.rotate(PI), Rotate(right_square, angle=PI), run_time=2
        )
        self.wait()