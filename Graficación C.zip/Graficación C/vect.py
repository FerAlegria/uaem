from manim import *

class VectorParallelOrOrthogonal(Scene):
    def construct(self):
        # Definir los vectores
        vector_v = np.array([2, 8, 12]) 
        vector_u = np.array([1, -4, 6])

        # Crear vectores en la escena
        vec_v = Arrow(start=ORIGIN, end=vector_v, buff=0, color=BLUE)
        vec_u = Arrow(start=ORIGIN, end=vector_u, buff=0, color=GREEN)

        # Añadir los vectores a la escena
        self.play(GrowArrow(vec_v), GrowArrow(vec_u))
        
        # Etiquetar los vectores
        label_v = MathTex(r"\vec{v} = \hat{i} - 18\hat{j}").next_to(vec_u, UP)
        label_u = MathTex(r"\vec{u} = -4\hat{i} + 12\hat{j}").next_to(vec_v, UP)
        
        self.play(Write(label_v), Write(label_u))

        # Verificar si son paralelos
        if (vector_v[0] / vector_u[0]) == (vector_v[1] / vector_u[1]):
            result_text = Text("Los vectores son paralelos", color=YELLOW).to_edge(DOWN)
        else:
            # Calcular el producto punto para verificar si son ortogonales
            dot_product = np.dot(vector_v[:2], vector_u[:2])
            if dot_product == 0:
                result_text = Text("Los vectores son ortogonales", color=YELLOW).to_edge(DOWN)
            else:
                result_text = Text("Los vectores no son paralelos ni ortogonales", color=YELLOW).to_edge(DOWN)

        # Descripción de los vectores
        description_text = Text("Los vectores tienen magnitudes y direcciones distintas.", color=WHITE).next_to(result_text, UP)
        
        # Mostrar la descripción y el resultado
        self.play(Write(description_text), Write(result_text))
        self.wait(2)