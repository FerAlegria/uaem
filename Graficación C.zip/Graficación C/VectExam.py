from manim import *

class VectoresActividad(Scene):
    def construct(self):
        # Definición de los vectores u y v
        u = np.array([-2, 8, -12])  # Vector u
        v = np.array([1, -4, 6])   # Vector v

        # Mostrar los componentes iniciales
        texto_u = MathTex(r"\mathbf{u} = -2\hat{i} + 8\hat{j} - 12\hat{k}")
        texto_v = MathTex(r"\mathbf{v} = 1\hat{i} - 4\hat{j} + 6\hat{k}")
        texto_u.shift(UP * 2)
        texto_v.shift(UP)

        # Agregar vectores al gráfico 3D
        ejes = ThreeDAxes()
        vector_u = Arrow3D(start=[0, 0, 0], end=u, color=BLUE, stroke_width=5)
        vector_v = Arrow3D(start=[0, 0, 0], end=v, color=GREEN, stroke_width=5)

        # Calcular el producto punto y magnitudes
        producto_punto = np.dot(u, v)
        magnitud_u = np.linalg.norm(u)
        magnitud_v = np.linalg.norm(v)

        # Mostrar magnitudes y ángulo entre vectores
        magnitudes_texto = MathTex(
            r"|\mathbf{u}| = " + f"{magnitud_u:.2f},\; |\mathbf{v}| = {magnitud_v:.2f}"
        )
        angulo = np.arccos(producto_punto / (magnitud_u * magnitud_v))
        angulo_texto = MathTex(r"\theta = " + f"{np.degrees(angulo):.2f}^\circ")
        magnitudes_texto.shift(DOWN * 2)
        angulo_texto.shift(DOWN * 3)

        # Verificar ortogonalidad o paralelismo
        if producto_punto == 0:
            conclusion = MathTex(r"\text{Los vectores son ortogonales.}")
        elif np.allclose(u / np.linalg.norm(u), v / np.linalg.norm(v)):
            conclusion = MathTex(r"\text{Los vectores son paralelos.}")
        else:
            conclusion = MathTex(r"\text{Los vectores no son ni ortogonales ni paralelos.}")
        conclusion.shift(DOWN * 4)

        # Animaciones
        self.add(ejes)
        self.play(Write(texto_u), Write(texto_v))
        self.wait(1)
        self.play(Create(vector_u), Create(vector_v))
        self.wait(1)
        self.play(Write(magnitudes_texto), Write(angulo_texto))
        self.wait(1)
        self.play(Write(conclusion))
        self.wait(2)

