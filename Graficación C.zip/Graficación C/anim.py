import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

# Configurar el lienzo para la animación
fig, ax = plt.subplots()
ax.set_xlim(-10, 10)
ax.set_ylim(-10, 10)

# Crear listas para almacenar los elementos que se irán dibujando
elements = []

# Función para dibujar la primera parte (la base de la nube)
def draw_step1():
    base = plt.Line2D([-5, 5], [0, 0], color='gray', linewidth=2)
    elements.append(base)
    ax.add_line(base)

# Función para dibujar la segunda parte (la forma general de la nube)
def draw_step2():
    cloud_shape = plt.Line2D([-4, -2], [2, 4], color='gray', linewidth=2)
    elements.append(cloud_shape)
    ax.add_line(cloud_shape)

# Función para dibujar la tercera parte (completar el contorno de la nube)
def draw_step3():
    cloud_shape = plt.Line2D([-2, 2], [4, 4], color='gray', linewidth=2)
    elements.append(cloud_shape)
    ax.add_line(cloud_shape)

# Función para dibujar la cuarta parte (la nube completa y el rayo)
def draw_step4():
    cloud_shape = plt.Line2D([2, 4], [4, 2], color='gray', linewidth=2)
    elements.append(cloud_shape)
    ax.add_line(cloud_shape)
    ray = plt.Line2D([0, 1], [0, -3], color='gray', linewidth=2)
    elements.append(ray)
    ax.add_line(ray)

# Función para agregar los ojos y la sonrisa en la nube
def draw_step5():
    eye_left = plt.Circle((-2, 2), 0.3, color='black')
    eye_right = plt.Circle((2, 2), 0.3, color='black')
    smile = plt.Arc((0, 1), 3, 2, theta1=0, theta2=180, color='black')
    elements.extend([eye_left, eye_right, smile])
    ax.add_patch(eye_left)
    ax.add_patch(eye_right)
    ax.add_patch(smile)

# Función de animación que se ejecutará en cada cuadro
def animate(i):
    # Limpiar elementos anteriores
    for element in elements:
        element.remove()
    elements.clear()
    
    # Dibujar en el orden correcto según el cuadro actual
    if i == 0:
        draw_step1()
    elif i == 1:
        draw_step2()
    elif i == 2:
        draw_step3()
    elif i == 3:
        draw_step4()
    elif i == 4:
        draw_step5()

# Crear y ejecutar la animación
ani = animation.FuncAnimation(fig, animate, frames=5, interval=1000, repeat=False)
plt.show()
