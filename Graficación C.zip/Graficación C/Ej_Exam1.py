from manim import *

class FondoLaboratorio(VGroup):
    """Clase para crear el fondo completo del laboratorio."""
    @staticmethod
    def crear_fondo():
        """Crea y devuelve un grupo de elementos que forman el fondo completo."""
        elementos = VGroup()

        # Crear el piso
        tile_size = 0.5
        num_tiles_x = int(config.frame_width / tile_size) + 10
        num_tiles_y = 6
        tiles = VGroup()
        for i in range(num_tiles_x):
            for j in range(num_tiles_y):
                color = BLUE if (i + j) % 2 == 0 else WHITE
                tile = Square(side_length=tile_size).set_fill(color, opacity=1)
                tile.set_stroke(GRAY, width=0.5)
                tile.move_to(np.array([
                    i * tile_size - config.frame_width / 2 + tile_size / 2,
                    j * tile_size - config.frame_height / 2 + tile_size / 2 - 1,
                    0
                ]))
                tiles.add(tile)
        elementos.add(tiles)

        # Crear la pared
        pared = Rectangle(width=config.frame_width, height=5.5).set_fill(GRAY, opacity=0.8)
        pared.to_edge(UP)
        elementos.add(pared)

        return elementos


class EscenaConNubeTriste(Scene):
    def construct(self):
        # Crear el fondo
        fondo = FondoLaboratorio.crear_fondo()
        self.add(fondo)

        # Crear la nube (personaje)
        nube = VGroup(
            Circle(radius=1, color=BLUE, fill_opacity=1).shift(LEFT),
            Circle(radius=1.2, color=BLUE, fill_opacity=1),
            Circle(radius=1, color=BLUE, fill_opacity=1).shift(RIGHT),
        ).scale(0.5).to_edge(UP, buff=1)

        # Crear ojos y boca triste
        ojo_izq = Circle(radius=0.1, color=BLACK, fill_opacity=1).move_to(nube.get_center() + LEFT * 0.2 + UP * 0.1)
        ojo_der = Circle(radius=0.1, color=BLACK, fill_opacity=1).move_to(nube.get_center() + RIGHT * 0.2 + UP * 0.1)
        boca = ArcBetweenPoints(
            nube.get_center() + LEFT * 0.2 + DOWN * 0.1,
            nube.get_center() + RIGHT * 0.2 + DOWN * 0.1,
            angle=-PI / 2,
            color=BLACK
        )

        # Crear el globo de texto
        globo = SVGMobject("speech_bubble.svg").scale(0.3).next_to(nube, UP, buff=0.5)
        texto = Text("Estoy triste...", font_size=24).next_to(globo, UP, buff=0.1)

        # Agrupar la nube y sus componentes
        personaje = VGroup(nube, ojo_izq, ojo_der, boca, globo, texto)

        # Añadir a la escena
        self.add(personaje)

        # Animar el movimiento del personaje de izquierda a derecha
        self.play(personaje.animate.shift(RIGHT * 4), run_time=4)
        self.wait()
