from manim import *

class VectorMenu(Scene):
    def construct(self):
        # Crear título del menú
        menu_title = Text("Seleccione una opción para los vectores").to_edge(UP)
        self.play(Write(menu_title))

        # Opciones del menú
        option_a = Text("1. \vec{a} y \vec{b}").next_to(menu_title, DOWN, buff=1)
        option_b = Text("2. \vec{a} y otro vector personalizado").next_to(option_a, DOWN, buff=0.5)

        # Mostrar opciones
        self.play(Write(option_a), Write(option_b))

        # Resaltar opción seleccionada (simularemos que el usuario elige la primera opción)
        highlight_box = SurroundingRectangle(option_a, color=YELLOW)
        self.play(Create(highlight_box))
        self.wait(1)

        # Transición al cálculo de vectores
        self.play(FadeOut(menu_title, option_a, option_b, highlight_box))
        self.animate_vectors()

    def animate_vectors(self):
        # Definir los vectores
        vector_a = np.array([4, -1, 0])
        vector_b = np.array([2, 8, 0])

        # Crear vectores en la escena
        vec_a = Arrow(start=ORIGIN, end=vector_a, buff=0, color=BLUE)
        vec_b = Arrow(start=ORIGIN, end=vector_b, buff=0, color=GREEN)

        # Añadir los vectores a la escena
        self.play(GrowArrow(vec_a), GrowArrow(vec_b))
        
        # Etiquetar los vectores
        label_a = MathTex(r"\vec{a} = 4\hat{i} - \hat{j}").next_to(vec_a, UP)
        label_b = MathTex(r"\vec{b} = 2\hat{i} + 8\hat{j}").next_to(vec_b, UP)
        
        self.play(Write(label_a), Write(label_b))

        # Verificar si son paralelos
        if (vector_a[0] / vector_b[0]) == (vector_a[1] / vector_b[1]):
            result_text = Text("Los vectores son paralelos", color=YELLOW).to_edge(DOWN)
        else:
            # Calcular el producto punto para verificar si son ortogonales
            dot_product = np.dot(vector_a[:2], vector_b[:2])
            if dot_product == 0:
                result_text = Text("Los vectores son ortogonales", color=YELLOW).to_edge(DOWN)
            else:
                result_text = Text("Los vectores no son paralelos ni ortogonales", color=YELLOW).to_edge(DOWN)

        # Mostrar resultado
        self.play(Write(result_text))
        self.wait(2)
