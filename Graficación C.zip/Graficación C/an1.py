import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

class BackgroundScene:
    def __init__(self, ax, x_range=(-5, 5), y_range=(-2, 5)):
        self.ax = ax
        self.x_range = x_range
        self.y_range = y_range
        self.buildings = []
        self.create_sky()
        self.create_cityscape()
        self.create_moon()  # Añadir la luna al escenario

    def create_sky(self):
        # Dibujar un fondo de cielo en negro
        self.ax.set_xlim(self.x_range)
        self.ax.set_ylim(self.y_range)
        self.ax.set_aspect('equal')
        self.ax.axis('off')
        sky = patches.Rectangle((self.x_range[0], 0), 
                                width=self.x_range[1] - self.x_range[0], 
                                height=self.y_range[1] - 0, 
                                color="black")  # Color de cielo negro
        self.ax.add_patch(sky)

    def create_cityscape(self):
        # Crear una fila de edificios en la parte inferior con ventanas
        building_colors = ["gray", "dimgray", "darkgray", "slategray"]
        for x in np.arange(self.x_range[0], self.x_range[1], 2):
            height = np.random.uniform(1.5, 3)  # Altura aleatoria para cada edificio
            color = np.random.choice(building_colors)
            building = patches.Rectangle((x, -2), width=1.8, height=height, edgecolor="black", facecolor=color)
            self.buildings.append(building)
            self.ax.add_patch(building)
            self.add_windows(x, height)

    def add_windows(self, building_x, building_height):
        # Añadir ventanas en filas y columnas dentro de cada edificio
        window_width, window_height = 0.2, 0.3
        for row in np.arange(-1.8, building_height - 2, 0.5):  # Espacio vertical entre ventanas
            for col in np.arange(building_x + 0.2, building_x + 1.6, 0.4):  # Espacio horizontal entre ventanas
                window_color = "yellow" if np.random.rand() > 0.7 else "black"
                window = patches.Rectangle((col, row), window_width, window_height, facecolor=window_color, edgecolor="black")
                self.ax.add_patch(window)

    def create_moon(self):
        # Añadir la luna en la esquina superior derecha
        moon = patches.Circle((4, 4), radius=0.5, edgecolor="white", facecolor="lightgray")
        self.ax.add_patch(moon)

    def display_scene(self):
        plt.show()

# Configuración de la figura principal
fig, ax = plt.subplots(figsize=(8, 6))
scene = BackgroundScene(ax)
scene.display_scene()
