import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection


# Coordenadas del polígono
x = [13, 1, 0, 2, 6, 8, 12, 8.5, 8.5, 6, 5, 6.8, 7, 3, 2.5, 4, 3, 1]
y = [13, 7, 4, 0, 0.5, 3.5, 4.5, 8, 6, 4, 6, 8, 9, 10, 8, 8, 6.8, 7]

# Empaquetamos las coordenadas en una lista de vértices
vertices = np.column_stack((x, y))

# Dibujar el polígono original
plt.figure()
plt.plot(x, y, 'b-', marker='o', markerfacecolor='red', markeredgecolor='red')
plt.fill(x, y, 'b', alpha=0.1)  # Rellenar el polígono con color suave
plt.title("Polígono original")
plt.show()

# Asegúrate de tener scipy instalado
##!pip install scipy
from scipy.spatial import Delaunay

# Hacer la triangulación
triangulation = Delaunay(vertices)

# Lista de triángulos
triangles = vertices[triangulation.simplices]

# Dibujar los triángulos
fig, ax = plt.subplots()

# Creamos colores para cada triángulo
colors = plt.cm.get_cmap('tab10', len(triangles))
patches = []

for i, triangle in enumerate(triangles):
    polygon = Polygon(triangle, closed=True, edgecolor='black', facecolor=colors(i))
    patches.append(polygon)

# Añadir los triángulos al gráfico
p = PatchCollection(patches, match_original=True)
ax.add_collection(p)

# Dibujar el contorno del polígono original
plt.plot(x, y, 'b-', marker='o', markerfacecolor='red', markeredgecolor='red')

plt.title("Triangulación del polígono")
plt.show()

# Calcular el número de triángulos
num_triangulos = len(triangulation.simplices)
print(f"El número de triángulos que contiene el polígono es: {num_triangulos}")
