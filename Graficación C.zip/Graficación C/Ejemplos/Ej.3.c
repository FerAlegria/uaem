
# include < stdio .h>
# include < stdlib .h>
# include < unistd .h>

int main () {
    pid_t pid;
    int j, estado ;
    for(j =0;j <5;j ++) {
        pid = fork () ;
        if( pid != 0) {
            break;
        }
    }

    wait (& estado ) ;
    printf("El␣ padre ␣ del ␣ proceso ␣ %d␣es␣ %d,␣j␣=␣ %d\n", getpid (),
    getppid () , j) ;
    sleep (3) ;
 }
